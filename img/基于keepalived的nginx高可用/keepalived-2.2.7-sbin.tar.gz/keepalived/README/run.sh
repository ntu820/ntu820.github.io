#创建目录
mkdir -p /etc/keepalived
#拷贝配置文件到/etc/keepalived目录下
cp /usr/local/keepalived/etc/keepalived/keepalived.conf.sample /etc/keepalived/keepalived.conf
#复制keepalived脚本到/etc/init.d/ 目录(可忽略)
cp ./keepalived /etc/init.d/
#拷贝keepalived脚本到/etc/sysconfig/ 目录
cp /usr/local/keepalived/etc/sysconfig/keepalived /etc/sysconfig/
